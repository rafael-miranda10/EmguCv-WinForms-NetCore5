# EmguCV4.x
This repository contains the code descibed in my YouTube channel. You can freely use the code and share it as per your needs.

YouTube Channel

https://www.youtube.com/channel/UCyMrNCSdcssSv_zKe9WsYig


